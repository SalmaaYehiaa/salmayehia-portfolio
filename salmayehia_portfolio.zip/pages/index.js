import Image from 'next/image'
export default function Home() {
  const PROFILE = {
    name: 'Salma Yehia Mohamed',
    role: 'Junior Software QA & Test Engineer',
    bio: 'Junior QA specializing in manual testing, API testing with Postman, and test documentation. Passionate about clean test design and edge cases.',
    email: 'salmayehia404@gmail.com',
    github: 'https://github.com/SalmaaYehiaa',
    linkedin: 'https://www.linkedin.com/in/salma-mohamed-47aa63177/',
    resume: '/Salma_Yehia_Mohamed_Software_Tester.pdf',
    photo: '/profile.jpg'
  }
  const projects = [
    { title: 'E-commerce Checkout & API Testing', desc: 'Designed test cases for checkout flow and API testing with Postman.' },
    { title: 'Performance Testing with JMeter', desc: 'Executed load and stress tests, analyzed results and reported bottlenecks.' },
    { title: 'Graduation Project – RPG Game', desc: 'Developed and tested an RPG game combining AI and VR.' }
  ]
  const stack = ['Manual Testing','API (Postman)','Selenium','JMeter','SQL','Java','C++','HTML/CSS/JS','GitHub','TFS Azure']

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 border-b border-yellow-500 bg-black/90 py-4">
        <div className="max-w-4xl mx-auto flex items-center justify-between px-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-brandYellow" />
            <div className="font-semibold">{PROFILE.name.split(' ')[0]}</div>
          </div>
          <nav className="hidden md:flex gap-6 text-sm text-yellow-300">
            <a href="#work" className="hover:text-brandYellow">Work</a>
            <a href="#about" className="hover:text-brandYellow">About</a>
            <a href="#stack" className="hover:text-brandYellow">Stack</a>
            <a href="#contact" className="hover:text-brandYellow">Contact</a>
          </nav>
          <a className="btn-yellow" href={PROFILE.resume}>Resume</a>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-16">
        <section className="text-center">
          <div className="mx-auto w-40 h-40 rounded-full border-4 border-yellow-500 overflow-hidden relative">
            <Image src={PROFILE.photo} alt={PROFILE.name} fill className="object-cover" />
          </div>
          <h1 className="text-4xl font-bold mt-6 text-yellow-400">{PROFILE.name}</h1>
          <p className="mt-2 text-yellow-300">{PROFILE.role}</p>
          <p className="mt-4 text-yellow-200 max-w-2xl mx-auto">{PROFILE.bio}</p>
          <div className="mt-6 flex items-center justify-center gap-3">
            <a className="btn-yellow" href="#work">See my work</a>
            <a className="border border-yellow-500 px-4 py-2 rounded-lg" href={'mailto:'+PROFILE.email}>Contact me</a>
          </div>
        </section>

        <section id="work" className="mt-14">
          <h2 className="text-2xl font-semibold mb-6 text-yellow-400">Projects</h2>
          <div className="grid md:grid-cols-3 gap-4">
            {projects.map((p,i)=>(
              <div key={i} className="card text-yellow-200">
                <h3 className="font-semibold text-yellow-400">{p.title}</h3>
                <p className="mt-2 text-sm">{p.desc}</p>
              </div>
            ))}
          </div>
        </section>

        <section id="about" className="mt-14">
          <h2 className="text-2xl font-semibold mb-4 text-yellow-400">About Me</h2>
          <div className="card text-yellow-200">
            <p>{PROFILE.bio}</p>
            <ul className="mt-4 list-disc pl-5 text-sm">
              <li>Manual & Exploratory Testing</li>
              <li>API Testing with Postman</li>
              <li>Performance basics with JMeter</li>
            </ul>
          </div>
        </section>

        <section id="stack" className="mt-14">
          <h2 className="text-2xl font-semibold mb-4 text-yellow-400">Stack</h2>
          <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-3">
            {stack.map((s,i)=>(
              <div key={i} className="card text-yellow-300">{s}</div>
            ))}
          </div>
        </section>

        <section id="contact" className="mt-14 mb-20">
          <h2 className="text-2xl font-semibold mb-4 text-yellow-400">Contact</h2>
          <div className="card text-yellow-200">
            <p>Email: <a className="underline" href={'mailto:'+PROFILE.email}>{PROFILE.email}</a></p>
            <p className="mt-2">LinkedIn: <a className="underline" href={PROFILE.linkedin}>{PROFILE.linkedin}</a></p>
            <p className="mt-2">GitHub: <a className="underline" href={PROFILE.github}>{PROFILE.github}</a></p>
          </div>
        </section>
      </main>
    </div>
  )
}
